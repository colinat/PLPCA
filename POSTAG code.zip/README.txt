Change line 29 of aspectmine_POS.py to your glove csv location.

to run method:

from aspectmine_POS import classifyDocument
classifyDocument(filelocation)