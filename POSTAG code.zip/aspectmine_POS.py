# -*- coding: utf-8 -*-
"""
Created on Sat Mar 28 17:45:01 2020

@author: nelso
"""
import pickle
with open("Onehotencoder.pickle","rb") as f:
    onehot_encoder = pickle.load(f)

with open("RandomForest.pickle","rb") as f:
    clf = pickle.load(f)
    
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from itertools import chain
import nltk

from sklearn.metrics.pairwise import cosine_similarity
from spacy_processing import getsentences

import spacy
nlp = spacy.load("en_core_web_sm")

print("spacy model loaded.")

glove = pd.read_csv(r"C:\Users\nelso\Documents\Data Science\Glove100.csv")
glove=glove.rename(columns = {'Unnamed: 0':'word'})

aspectwords = {'Products_services': 'business', 'Acquisitions': 'acquisitions', 'Sales': 'sales', 'Op_costs': 'cost', 'Earnings': 'earnings', 'Competition': 'competition', 'Debt': 'debt', 'Op_risks' : 'risk', 'Organic_expansion': 'growth'}
aspects = {0:'Products_services', 
           1:'Acquisitions',
           2:'Sales',
           3:'Op_costs',
           4:'Earnings',
           5:'Competition',
           6:'Debt',
           7:'Op_risks',
           8:'Organic_Expansion'}

def gettokens(line):
    doc = nlp(line)
    mytokens = [token.text for token in doc]

    mywords = []
    lemmas = []
    mytags = []  
    myshape = []
    mydep = []

    for token in doc:
        mydep.append(token.dep_)
        mywords.append(token.lower_)
        lemmas.append(token.lemma_)
        mytags.append(token.tag_)
        myshape.append(token.shape_)
    
    mytags = ['START','START']+mytags+['END','END']
    
    aspectdf2 = pd.DataFrame({'Word': mywords,
                            'Lemma': lemmas,
                            'POSTagneg2': mytags[0:len(mytags)-4],
                            'POSTagneg1': mytags[1:len(mytags)-3],
                            'POSTag': mytags[2:len(mytags)-2],
                            'POSTagpos1': mytags[3:len(mytags)-1],
                            'POSTagpos2': mytags[4:len(mytags)],
                            'Shape': myshape,
                            'Dependency': mydep})
        
    aspectdf2['rowind'] = range(len(aspectdf2))
    return(aspectdf2)

def classifywordAspect(word):
    word_sim = []
    word_vector = glove[glove["word"] == word]
    word_vector = word_vector.iloc[:,1:101]
    
    if len(word_vector) == 0:
        return([0,0])
       
    for item in aspectwords.values():
        
        vect = glove[glove["word"] == item]
        myvect = vect.iloc[:,1:101]
        word_sim.append(cosine_similarity([myvect.iloc[0,:]],[word_vector.iloc[0,:]])[0,0])
    
    return([max(word_sim), aspects[word_sim.index(max(word_sim))], word])

def getAspects(line):
    
    df = gettokens(line)
    model_params = ['POSTagneg2','POSTagneg1','POSTag','POSTagpos1','POSTagpos2','Dependency']
    model_nonparams = ['Word','Lemma','Shape','rowind']
    
    predicting = df[model_params]
    
    onehotencoded2 = onehot_encoder.transform(predicting)
    
    predictions = clf.predict(onehotencoded2)
    predictions_prob = clf.predict_proba(onehotencoded2)[:,1]
    
    df['predictions'] = predictions
    df['predictions_prob'] = predictions_prob
    
    predicted_aspect_word = df[df['predictions'] == 1]["Word"]
    
    scores = [[0,0," "]]
    
    for item in predicted_aspect_word:
        scores.append(classifywordAspect(item))
    
    # scoredf = pd.concat(scores)
    scores = pd.DataFrame(scores, columns = ["Score","Aspect", "Word"])
    
    return(scores[scores["Score"] == max(scores["Score"])].head(1))

def classifyDocument(file):
    myclasses = []
    mytranscript = getsentences(file)
    
    for line in mytranscript:
        df = getAspects(line)
        df['Sentence'] = line
        print(df)
        myclasses.append(df)
    
    pd.concat(myclasses).to_csv("output_aspect.csv", encoding='utf-8')
    # return(pd.concat(myclasses))
    
# mysentences = getsentences(r'Data/Western Union Co_20170502-Text2.txt')
# mydata = classifyDocument(r'Data/Western Union Co_20170502-Text2.txt')

